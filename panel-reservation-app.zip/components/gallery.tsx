'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const slides = [
  { src: '/gallery-1.png', alt: 'Animated GIF' },
  { src: '/gallery-2.png', alt: 'Photo' },
]

export function Gallery() {
  const [index, setIndex] = useState(0)

  const prev = () => setIndex((i) => (i === 0 ? slides.length - 1 : i - 1))
  const next = () => setIndex((i) => (i === slides.length - 1 ? 0 : i + 1))

  return (
    <div className="rounded-3xl border border-border bg-card/60 p-4 shadow-xl backdrop-blur">
      <h3 className="mb-3 px-1 text-sm font-semibold text-foreground">Gallery</h3>
      <div className="relative overflow-hidden rounded-2xl">
        <div
          className="flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {slides.map((slide) => (
            <img
              key={slide.src}
              src={slide.src || '/placeholder.svg'}
              alt={slide.alt}
              className="aspect-video w-full shrink-0 object-cover"
            />
          ))}
        </div>

        <button
          type="button"
          onClick={prev}
          aria-label="Sebelumnya"
          className="absolute left-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/70 text-foreground backdrop-blur transition hover:bg-background/90"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          type="button"
          onClick={next}
          aria-label="Berikutnya"
          className="absolute right-3 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/70 text-foreground backdrop-blur transition hover:bg-background/90"
        >
          <ChevronRight className="h-5 w-5" />
        </button>

        <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
          {slides.map((slide, i) => (
            <button
              key={slide.src}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Slide ${i + 1}`}
              className={`h-2 rounded-full transition-all ${
                i === index ? 'w-6 bg-primary' : 'w-2 bg-muted-foreground/40'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
