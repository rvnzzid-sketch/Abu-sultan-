import {
  ArrowRight,
  Award,
  CheckCircle2,
  Clock,
  Cloud,
  Cpu,
  Database,
  Globe,
  Lock,
  MessageCircle,
  Rocket,
  Send,
  Server,
  Shield,
  ShieldCheck,
  Sparkles,
  Star,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react'
import { Gallery } from '@/components/gallery'

const stats = [
  { value: '99.9%', label: 'Uptime' },
  { value: '<50ms', label: 'Latency' },
  { value: '24/7', label: 'Support' },
]

const features = [
  {
    icon: Zap,
    title: 'Instant Setup',
    desc: 'Panel aktif dalam hitungan detik setelah pembayaran',
    color: 'from-amber-400 to-orange-500',
  },
  {
    icon: Shield,
    title: 'Garansi 30 Hari',
    desc: 'Klaim hingga 3x jika ada masalah',
    color: 'from-emerald-400 to-green-500',
  },
  {
    icon: Clock,
    title: '24/7 Support',
    desc: 'Bantuan teknis via WhatsApp kapanpun',
    color: 'from-sky-400 to-blue-500',
  },
  {
    icon: Server,
    title: 'Anti Lag',
    desc: 'Server premium dengan uptime 99.9%',
    color: 'from-fuchsia-400 to-purple-500',
  },
]

const tech = [
  {
    icon: Cpu,
    title: 'Pterodactyl Panel',
    desc: 'Panel management terbaik untuk game server dan bot hosting dengan UI modern',
  },
  {
    icon: Database,
    title: 'NVMe Storage',
    desc: 'Penyimpanan super cepat dengan teknologi NVMe SSD untuk performa maksimal',
  },
  {
    icon: Cloud,
    title: 'Cloud Infrastructure',
    desc: 'Infrastruktur cloud enterprise dengan redundansi tinggi dan backup otomatis',
  },
  {
    icon: Globe,
    title: 'Global Network',
    desc: 'Jaringan server dengan latency rendah untuk koneksi stabil ke seluruh Indonesia',
  },
  {
    icon: Lock,
    title: 'DDoS Protection',
    desc: 'Perlindungan dari serangan DDoS level enterprise untuk keamanan maksimal',
  },
  {
    icon: Rocket,
    title: 'Auto Scaling',
    desc: 'Resource otomatis menyesuaikan dengan kebutuhan bot WhatsApp Anda',
  },
]

const reasons = [
  {
    icon: Award,
    title: 'Harga Termurah',
    desc: 'Mulai dari Rp 3.000 per bulan dengan spesifikasi lengkap',
  },
  {
    icon: Users,
    title: 'Dipercaya Ribuan User',
    desc: 'Sudah melayani lebih dari 1258+ pesanan dengan rating 5 bintang',
  },
  {
    icon: ShieldCheck,
    title: 'Garansi Uang Kembali',
    desc: 'Tidak puas? Garansi refund 100% dalam 7 hari pertama',
  },
]

const avatars = [
  { letter: 'A', color: 'from-sky-400 to-blue-500' },
  { letter: 'B', color: 'from-fuchsia-400 to-purple-500' },
  { letter: 'C', color: 'from-emerald-400 to-green-500' },
  { letter: 'D', color: 'from-amber-400 to-orange-500' },
]

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Ambient glow background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[500px] w-[500px] rounded-full bg-accent/10 blur-[130px]" />
      </div>

      <div className="mx-auto w-full max-w-xl px-5 py-8">
        {/* Header */}
        <header className="mb-8 flex items-center gap-3">
          <img
            src="/ptero-mascot.png"
            alt="Ptero Mascot"
            className="h-14 w-14 rounded-2xl border border-border shadow-lg"
          />
          <div>
            <h1 className="bg-gradient-to-r from-primary to-accent bg-clip-text text-2xl font-extrabold text-transparent">
              Panel Ptero
            </h1>
            <p className="text-sm text-muted-foreground">Hosting Premium Indonesia</p>
          </div>
        </header>

        {/* Gallery */}
        <section className="mb-8">
          <Gallery />
        </section>

        {/* Hero */}
        <section className="mb-10">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
            <Sparkles className="h-4 w-4" />
            {'#1 Panel Termurah di Indonesia'}
          </div>

          <h2 className="text-pretty text-4xl font-extrabold leading-tight tracking-tight">
            <span className="text-foreground">Hosting</span>
            <br />
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
              WhatsApp Bot
            </span>
            <br />
            <span className="text-foreground">Terbaik &amp; Termurah</span>
          </h2>

          <p className="mt-5 leading-relaxed text-muted-foreground">
            Panel Pterodactyl dengan performa tinggi untuk hosting bot WhatsApp, Discord, Telegram
            dan aplikasi Node.js lainnya. Garansi 30 hari dengan harga mulai dari{' '}
            <span className="font-semibold text-primary">Rp 3.000</span>
          </p>

          <div className="mt-7 flex gap-8">
            {stats.map((stat) => (
              <div key={stat.label}>
                <p className="text-2xl font-extrabold text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Counter card */}
        <section className="mb-10">
          <div className="flex items-center gap-4 rounded-2xl border border-border bg-card/60 p-5 backdrop-blur">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success/15 text-success">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <p className="flex items-center gap-2 text-2xl font-extrabold text-foreground">
                1,258<span className="text-success">+</span>
                <TrendingUp className="h-5 w-5 text-success" />
              </p>
              <p className="text-sm text-muted-foreground">Panel Berhasil Dibuat</p>
            </div>
          </div>
        </section>

        {/* Keunggulan Kami */}
        <section className="mb-10">
          <h3 className="mb-5 text-xl font-bold text-foreground">Keunggulan Kami</h3>
          <div className="grid grid-cols-2 gap-4">
            {features.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur transition hover:border-primary/40"
              >
                <div
                  className={`mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${f.color} text-white shadow-lg`}
                >
                  <f.icon className="h-5 w-5" />
                </div>
                <h4 className="mb-1 font-semibold text-foreground">{f.title}</h4>
                <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Teknologi Premium */}
        <section className="mb-10">
          <h3 className="mb-5 text-xl font-bold text-foreground">Teknologi Premium</h3>
          <div className="flex flex-col gap-4">
            {tech.map((t) => (
              <div
                key={t.title}
                className="flex items-start gap-4 rounded-2xl border border-border bg-card/60 p-5 backdrop-blur transition hover:border-primary/40"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                  <t.icon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="mb-1 font-semibold text-foreground">{t.title}</h4>
                  <p className="text-sm leading-relaxed text-muted-foreground">{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Mengapa Memilih Kami */}
        <section className="mb-10">
          <h3 className="mb-5 text-xl font-bold text-foreground">Mengapa Memilih Kami?</h3>
          <div className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur">
            <ul className="flex flex-col gap-5">
              {reasons.map((r) => (
                <li key={r.title} className="flex items-start gap-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <r.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{r.title}</p>
                    <p className="text-sm leading-relaxed text-muted-foreground">{r.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Contact buttons */}
        <section className="mb-8 flex gap-4">
          <a
            href="#"
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-success/40 bg-success/10 px-4 py-3 font-medium text-success transition hover:bg-success/20"
          >
            <MessageCircle className="h-5 w-5" />
            Contact Admin
          </a>
          <a
            href="#"
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-4 py-3 font-medium text-primary transition hover:bg-primary/20"
          >
            <Send className="h-5 w-5" />
            Channel WhatsApp
          </a>
        </section>

        {/* Social proof */}
        <section className="mb-8 flex items-center gap-3">
          <div className="flex -space-x-2">
            {avatars.map((a) => (
              <span
                key={a.letter}
                className={`flex h-8 w-8 items-center justify-center rounded-full border-2 border-background bg-gradient-to-br ${a.color} text-xs font-bold text-white`}
              >
                {a.letter}
              </span>
            ))}
          </div>
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">User puas</span>
        </section>

        {/* CTA */}
        <section className="text-center">
          <button
            type="button"
            className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-primary via-primary to-accent px-6 py-4 text-lg font-bold text-primary-foreground shadow-xl shadow-primary/20 transition hover:brightness-110"
          >
            Mulai Order Sekarang
            <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
          </button>
          <p className="mt-3 text-sm text-muted-foreground">
            Proses instan • Pembayaran mudah via QRIS
          </p>
        </section>
      </div>
    </main>
  )
}
